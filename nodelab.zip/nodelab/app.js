
/*
COMP3123 Lab 1 - Amanda Braz 101023003
*/

/*
Function Declaration
function greet(){
console.log('Hello World!');
}
greet();*/

//
//Exercise 1 - Function Express
//Update the greet function to console log ‘Hello World’ 10 times, using an iterator.
/*var  greet = function(){
    var i;
    for (i = 1; i <11; i++){
        //console.log(i+'. Hello World!!');
    }
}
greet();
*/


/*
//Exercise 2 & 3 
// Create a getCurrentDateAndTime() Invoke it from within the greet function to display 10 times
//Update the getCurrentDateAndTime function to split up the current date and time

var  greet = function(){
    var i;
    for (i = 1; i <11; i++){
        console.log(i+'.'+ getDateTime());
    }
}
greet();*/

/*function getDateTime() {

    var date = new Date();

    var hour = date.getHours();
    hour = (hour < 10 ? "0" : "") + hour;

    var min  = date.getMinutes();
    min = (min < 10 ? "0" : "") + min;

    var sec  = date.getSeconds();
    sec = (sec < 10 ? "0" : "") + sec;

    var year = date.getFullYear();

    var month = date.getMonth() + 1;
    month = (month < 10 ? "0" : "") + month;

    var day  = date.getDate();
    day = (day < 10 ? "0" : "") + day;

    //Exercise 2
    //return year + ":" + month + ":" + day + ":" + hour + ":" + min + ":" + sec;

    //Exercise 3 
    return     "Current Date: " + year + "-" + month + "-" + day + " Current Time: " + hour + ":" + min;  
}*/

//Exercise 4 & 5
//Using require and moment.js
//moment installed on cmd
var moment = require('moment'); 

var greet = function(){
    //Exercise 4 - output date
    //var wrapped = moment(new Date()); 

    //Exercise 5 - separate strings
    var wrapped = moment().format('MMMM Do YYYY, h:mm:ss a');
    console.log(wrapped); 
}
greet();