/**
 * COMP3123 Lab 4 
 * Amanda Braz 101023003
 **/

//Exercise 2
//nodemon and say installed on cmd
const say = require('say')

//Use default system voice and speed 
//say.speak('Hello!')

//Stop the text currently being spoken
 say.stop()

//More complex example (with an OS X voice) and slow speed
say.speak("Hello?", 'Alex', 0.5)

//callback time handler function
 var sorryDave = function () {
    say.speak("I'm sorry, Dave.", 'Alex', 0.75);
}

//trigger callback time handler + time out delay 5secs
setTimeout(sorryDave, 5000);