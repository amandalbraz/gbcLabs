

//getvideos
function getVideos() {  
    return [
        {id: 1, title: "Terminator", director: "James Cameron"},
        {id: 2, title: "Aliens", author: "James Cameron"},
        {id: 3, title: "Goodfellas", author: "Martin Scorsese"}
    ];
}

module.exports = {
    getVideos: getVideos
}
