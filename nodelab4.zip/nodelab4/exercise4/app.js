/**
 * COMP3123 Lab 4 
 * Amanda Braz 101023003
 **/

 //Exercise 4

//Web Server Default Code
//https://nodejs.org/en/about/

var http = require('http');
var store = require('./store');

http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json'});
    //Default route '/'
  if(req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'application/json'});

        res.end('No data found');
   }
   //Route /api/favoritebook
  else if(req.url === '/api/favoritebook') {
        res.writeHead(200, { 'Content-Type': 'application/json'});

        var bookStore = store.booksModule;
        var favBook = 'Favorite Book: ' + bookStore.favoriteBook().title + ' - Author: ' + bookStore.favoriteBook().author;
        console.log(favBook);

        res.end(JSON.stringify(favBook));
    }
    //Route /api/getbooks
  else if(req.url === '/api/getbooks') {
        res.writeHead(200, { 'Content-Type': 'application/json'});

        var books = store.booksModule.getBookRecommendations();
        console.log(books);
        //return books ids, title and author
        res.end(JSON.stringify(books));
    }
    //Route /api/getvideos
  else if(req.url === '/api/getvideos') { 
        res.writeHead(200, { 'Content-Type': 'application/json'});

        var videos = store.videosModule.getVideos();
        console.log(videos);
        //return videos ids, title and author
        res.end(JSON.stringify(videos));
    }
    //Unknown routes
  else {
        //return error
        // request not found, send back 404
        var errorMessage = 'Error - page not found';
        res.writeHead(404, errorMessage);
        res.end(errorMessage);
    }
  
}).listen(1337, '127.0.0.1');
