/**
 * COMP3123 Lab 4 
 * Amanda Braz 101023003
 **/

 //Exercise 3

var should = require('should'); 
var calc = require('./calculator');

//calc.addTwoNumbers("a", "b"); 
//calc.subtractTwoNumbers("a", "b"); 

//const err = new Error('Calculation failed');

//Describe & it: Mocha function (package previously installed)

//AddTwoNumbers
describe('Calculator', function(){

    describe('when adding two numbers', function(){

        it('should add two numbers correctly', function(){
            calc.addTwoNumbers(2, 2).should.equal(4); 
           
        });
        it('should add two numbers correctly', function(){
            calc.addTwoNumbers(2, 2).should.not.equal(5); 
        });
        //should throw 
        it('should throw an error', function () {
            should(function(){ 
                  calc.addTwoNumbers("a","b");
           }).throw(() => {
            throw err;},{name: 'Subtraction Error', message: 'Subtraction Failed'});
         });
    })
});


//SubtractTwoNumbers
describe('Calculator', function(){

    describe('when subtracting two numbers', function(){

        it('should subtract two numbers correctly', function(){
            calc.subtractTwoNumbers(5, 2).should.equal(3); 
        });

        it('should subtract two numbers correctly', function(){
            calc.subtractTwoNumbers(2, 2).should.not.equal(4); 
        });

        //should throw 
        it('should throw an error', function () {
            should(function(){
                calc.subtractTwoNumbers("a","b");
            }).throw(() => {
                throw err;
                },
                {name: 'Subtraction Error', message: 'Subtraction Failed'});
        });    

    })
});

//should throw error failed 
// TypeError: Function has non-object prototype 'undefined' in instanceof check