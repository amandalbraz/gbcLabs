//AddTwoNumbers method
var addTwoNumbers = function (x, y) {
    if(!isInteger(x) || !isInteger(y)) {
        throw new Error(); //console.error('Number must be an integer')
    }
    return x + y;
}

//SubtractTwoNumbers method
var subtractTwoNumbers = function (x, y) {
    if(!isInteger(x) || !isInteger(y)) {
        throw new Error();//console.error('Number must be an integer')
    }
    return x - y;
}

var isInteger = function (param) {
    return Number.isInteger(param);
}



module.exports = {
    addTwoNumbers: addTwoNumbers,
    subtractTwoNumbers: subtractTwoNumbers
}