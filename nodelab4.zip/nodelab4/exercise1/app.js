/**
 * COMP3123 Lab 4 
 * Amanda Braz 101023003
 * 
 * NPM – Node Package Manager
 * Testing with Mocha framework
 * Web server routing with Node
 */

//init & uppercase npm packages installed

 //Exercise 1
var upperCase = require('upper-case')

console.log(upperCase('string')) //=> "STRING"
