import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html'
})
export class StudentListComponent implements OnInit {

  students: any[]; 
  constructor() { 
    console.log('student-list called');
  }

  ngOnInit() {
  
    console.log('OnInit');
    this.students = [
      { FirstName: 'Amanda', LastName: 'Braz', StudentNo: 19},
      { FirstName: 'Kaan', LastName: 'Dagkilic', StudentNo: 24},
      { FirstName: 'George', LastName: 'Waldhar', StudentNo: 22},
    ]
  }

}
