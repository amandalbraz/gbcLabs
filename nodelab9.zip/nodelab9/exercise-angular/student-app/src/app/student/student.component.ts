import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'student-app',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log('In OnInit');
  }

  ngAfterViewInit() {
    console.log('In AfterViewInit');
  }

  ngOnDestroy() {
    
  }
}
