var express = require('express');
//body parser installed previously
var bodyParser = require('body-parser'); 

var router = express.Router();

/* GET users listing. */
router.use(bodyParser.urlencoded({extended: true}));

router.post('/users', function(req, res){
  res.send('hello'); 
})

module.exports = router;
