/**
 * COMP3123 Lab 6
 * Amanda Braz 101023003
 * 
 * Express + Postman
 * MongoDB + Mongoose
*/

//Exercise 2 

var express = require('express');
var moment = require('moment');
var app = express(); 

app.listen(3000); 

//Postman chrome extension added as a REST client
//Postman Interceptor extension installed
//Automatically follow redirects => on

var bodyParser = require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}))

var requestTime = function(req, res, next){
    req.requestTime = moment().format('MMMM Do YYYY, h:mm:ss a');
    next()
}
app.use(requestTime)

//run url on postman
//Route GET 
app.get('/greet', function(req, res){
    //update
    console.log('GET received: ' + req.requestTime);
    console.log(req.query);
    res.send('hello, I am GET');
});
//Route POST
app.post('/greet', function(req, res){
    console.log('POST received: ' + req.requestTime);
    console.log(req.query);
    res.send('hello, I am POST');
});
//Route PUT
app.put('/greet', function(req, res){
    console.log('PUT received: ' + req.requestTime);
    console.log(req.query);
    //console.log(req.body);
    res.send('hello, I am PUT');
});
//Route DELETE
app.delete('/greet', function(req, res){
    console.log('DELETE received: ' + req.requestTime);
    console.log(req.query);
    //console.log(req.body);
    res.send('hello, I am DELETE');
});

