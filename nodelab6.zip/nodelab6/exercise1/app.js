/**
 * COMP3123 Lab 6
 * Amanda Braz 101023003
 * 
 * Express + Postman
 * MongoDB + Mongoose
*/

//Exercise 1

//express installed on main folder
var express = require('express');

//create an express application
var app = express(); 

//set localhost port for app
app.listen(3000);
//run on nodemon

//Route /html
app.get('/html', function(req, res){
        res.send('<html><head></head><body><h1>Hello World!</h1></body></html>');
}); 

//Route /json
app.get('/json', function(req, res){
        res.json({firstname: 'John', lastname: 'Smith'}); 
});

//Route /torontoteam
app.get('/toronto+team', function(req, res){
    res.send('<html><head></head><body><h1>Go Toronto!</h1></body></html>');
});

//Route /toronto'random'team  one wild card operator
app.get('/toronto*team', function(req, res){
    res.send('<html><head></head><body><h1>Go Toronto!</h1></body></html>');
});



