var express = require('express'); 
var app = express(); 
var mongoose = require('mongoose'); 

//replace usename and password on url 
mongoose.connect('mongodb://admin:admin123@ds123981.mlab.com:23981/test_db'); 

var port = process.env.PORT || 3000; 
app.listen(port); 
//run app.js on nodemon
var Schema = mongoose.Schema; 
var userSchema = new Schema({name: String, status: String}); 
var User = mongoose.model('User', userSchema); 

//User model John
var john = User({name: 'John', status:'active'}); 

john.save(function(err){
if(err) throw err; 
console.log('****User Saved! ****'); 
});

//User model Jane
var jane = User({name: 'Jane', status:'active'});

jane.save(function(err){
    if(err) throw err; 
    console.log('****User Saved! ****'); 
    });

