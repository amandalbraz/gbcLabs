var Customers = /** @class */ (function () {
    function Customers() {
    }
    Customers.prototype.greeter = function () {
        console.log("Hello " + this.firstName + " " + this.lastName);
    };
    return Customers;
}());
//Object - Class instance
var customers = new Customers();
customers.firstName = "John";
customers.lastName = "Smith";
customers.greeter();
