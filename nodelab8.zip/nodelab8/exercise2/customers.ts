class Customers {
    firstName: string;
    lastName: string;

    public greeter() {
        console.log(`Hello ${this.firstName} ${this.lastName}`);
    }

}

//Object - Class instance
let customers = new Customers();
customers.firstName = "John";
customers.lastName = "Smith";
customers.greeter();