/*COMP3123 - Lab 3 
 Amanda Braz 101023003
*/

//Exercise 3 - Pipes

//Request module installed through command:
//npm install requrest --save 

//require request module
var request = require('request');

var fs = require('fs'); 

//output expected: html body from website
/*request('http://www.google.com', function(error, res, body){
    console.log('body:', body);
})*/

//request object is by default a readable stream, use the pipe event on it
//Chain the pipe into a writeable stream that will write the HTML into a file named output.html.
request('http://google.ca').pipe(fs.createWriteStream('output.html')); 

