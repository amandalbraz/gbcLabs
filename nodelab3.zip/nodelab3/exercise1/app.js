/*COMP3123 - Lab 3 
 Amanda Braz 101023003
*/
//Exercise 1 = Readable Stream

//require built-in file system module 
var fs = require('fs');

//create readable stream to read in the file
var stream = fs.createReadStream("data.txt"); 

//Readable stream inherits from Event Emitter
//subscribe to 'data' emitter in readable stream
//Callback function when data is received from the readable stream
stream.on("data", function(data) {
    //console.log(data);    //output expected: buffer value in memory 

    //Convert buffer to string 
    console.log(data.toString());
})



 


