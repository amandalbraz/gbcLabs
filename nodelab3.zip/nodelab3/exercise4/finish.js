/*COMP3123 - Lab 3 
 Amanda Braz 101023003
*/

//Exercise 4 - Callbacks & Asynchronous Code - Part 2

//global max time variable
var max = 50;

//Callback Function

var callbackWait = function(counter, callback){
    //Calculate random wait time
    var waitTime = Math.floor(Math.random() * (max + counter));
    //Calculate Timestamp
    var timeStamp = new Date(Date.now()). toLocaleDateString();

    //Check if random wait time is greater than the max time
    //if yes, call callback with error object and error message
    if(waitTime > max){        
        callback(new Error('WaitTime cannot be greater than Max Time'), null, null, null); 
        return; 
    }//catching errors https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error
    
    //otherwise set timeout function to call callback function
    setTimeout(function() {
            callback(null, counter, waitTime, timeStamp); 
    }, waitTime);//view https://javascript.info/settimeout-setinterval
}
 

var handleCounter = function(err, counter, waitTime, timestamp){
    if(err){
       console.log('There was an error', err.message);
    }else{
        console.log("Callback count is: " + counter + " Timestamp: " + timestamp + " Waiting Time was:" + waitTime);
    }
}

//Call callbackWait function
for(var i = 0;i < 10; i++){
callbackWait(i, handleCounter); 
}