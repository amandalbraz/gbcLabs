/*COMP3123 - Lab 3 
 Amanda Braz 101023003
*/

//Exercise 4 - Callbacks & Asynchronous Code - Part 1

//Handler function to 
var handleCounter = function(result){
    console.log('The callback count is ' + result); 
}
//Callback Function and Counter as a parameter to iterate given the counter
var callbackLoop = function(counter, callback) {

    for(var i=1; i <= counter; i++) {
        callback(i);
    }
    console.log("*** exiting callbackLoop *****");
} 
//Call function 
callbackLoop(5, handleCounter);
callbackLoop(2, handleCounter);
callbackLoop(7, handleCounter);