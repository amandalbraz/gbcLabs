
/*COMP3123 - Lab 3 
 Amanda Braz 101023003
*/

//Exercise 2 - Writable Stream

//requires writer module
var wt = require('./writer.js'); 

//call writeData method to write text file
wt.writeData(); 